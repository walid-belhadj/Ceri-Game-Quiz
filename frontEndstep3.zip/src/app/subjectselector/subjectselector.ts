import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-subjectselector',
  templateUrl: './subjectselector.component.html',
  styleUrls: ['./subjectselector.component.css']
})
export class subjectselectorComponent implements OnInit {

  @Input() subjectss: string[];

  @Output('selectedSubject')
  sendSelectedSubjectEmitter: EventEmitter<string> = new EventEmitter<string>();

  constructor() { }

  ngOnInit(): void {
  }
  onSubjectSelected = function(subject: string) : void {
    this.sendSelectedSubjectEmitter.emit(subject);
  }

}
