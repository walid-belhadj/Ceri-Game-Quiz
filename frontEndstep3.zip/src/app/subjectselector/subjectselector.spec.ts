import { ComponentFixture, TestBed } from '@angular/core/testing';

import { subjectselectorComponent } from './subjectselector.component';

describe('subjectselectorComponent', () => {
  let component: subjectselectorComponent;
  let fixture: ComponentFixture<subjectselectorComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ subjectselectorComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(subjectselectorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
